# 📱 PhotoVideoEditor Mobile

Kivy tabanlı video ve fotoğraf düzenleme mobil uygulaması

## 🚀 Özellikler

- 📸 **Fotoğraf Düzenleme**
  - Temel düzenlemeler (parlaklık, kontrast, doygunluk)
  - Filtreler ve efektler
  - Kırpma ve döndürme
  
- 🎬 **Video Düzenleme**
  - Video kesme ve birleştirme
  - Video filtreleri
  - Ses işleme

- 🎨 **Gelişmiş Özellikler**
  - Metin ve sticker ekleme
  - Çerçeveler ve kenarlıklar
  - Export ve paylaşım

## 📦 Kurulum

### Gereksinimler
- Python 3.9+
- Kivy ve bağımlılıkları

### Adımlar

1. **Repository'yi klonlayın:**
```bash
git clone https://github.com/yourusername/PhotoVideoEditor.git
cd PhotoVideoEditor
```

2. **Virtual environment oluşturun:**
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# veya
venv\Scripts\activate     # Windows
```

3. **Bağımlılıkları yükleyin:**
```bash
pip install -r requirements.txt
```

4. **Uygulamayı çalıştırın:**
```bash
python main.py
```

## 📱 Android APK Build

```bash
buildozer android debug
```

## 📂 Proje Yapısı

```
PhotoVideoEditor/
├── src/
│   ├── ui/           # Kullanıcı arayüzü
│   ├── core/         # Ana işlevler
│   ├── filters/      # Filtre algoritmaları
│   ├── utils/        # Yardımcı fonksiyonlar
│   └── assets/       # Görseller, iconlar
├── tests/           # Test dosyaları
├── docs/            # Dokümantasyon
├── requirements.txt # Bağımlılıklar
└── main.py         # Ana uygulama
```

## 🛠️ Geliştirme Durumu

### ✅ Tamamlanan
- [x] Temel proje yapısı
- [x] Splash screen
- [x] Ana menü
- [x] Temel navigasyon

### 🔄 Devam Eden
- [ ] Fotoğraf editörü
- [ ] Video editörü
- [ ] Filtre sistemi

### 📋 Planlanan
- [ ] Gelişmiş filtreler
- [ ] Paylaşım özellikleri
- [ ] Cloud entegrasyonu

## 📄 Lisans

MIT License

## 👥 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun
3. Değişikliklerinizi commit edin
4. Pull request gönderin

## 📞 İletişim

- **Email:** your.email@domain.com
- **GitHub:** [github.com/yourusername/PhotoVideoEditor] 