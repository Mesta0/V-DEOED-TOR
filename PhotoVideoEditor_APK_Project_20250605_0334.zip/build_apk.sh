#!/bin/bash

# 🚀 PhotoVideoEditor APK Build Script
# GitHub Codespaces veya Ubuntu'da çalıştır

echo "📱 PhotoVideoEditor APK Build başlıyor..."
echo "⏰ Tahmini süre: 10-15 dakika"
echo ""

# Renk kodları
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Fonksiyonlar
print_step() {
    echo -e "${BLUE}🔧 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# 1️⃣ Sistem güncelleme
print_step "Sistem güncelleniyor..."
sudo apt update -qq > /dev/null 2>&1
print_success "Sistem güncellendi"

# 2️⃣ Gerekli paketleri kur
print_step "Android build araçları kuruluyor..."
sudo apt install -y \
    git zip unzip openjdk-11-jdk python3-pip \
    autoconf libtool pkg-config zlib1g-dev \
    libncurses5-dev libncursesw5-dev libtinfo5 \
    cmake libffi-dev libssl-dev build-essential \
    libgl1-mesa-dev libgles2-mesa-dev \
    > /dev/null 2>&1

print_success "Android araçları kuruldu"

# 3️⃣ Python bağımlılıkları
print_step "Python bağımlılıkları kuruluyor..."
pip install --upgrade pip --quiet
pip install buildozer --quiet
pip install kivy[base] --quiet

print_success "Python paketleri kuruldu"

# 4️⃣ Java sürümünü kontrol et
print_step "Java sürümü kontrol ediliyor..."
java_version=$(java -version 2>&1 | grep version | awk '{print $3}' | sed 's/"//g')
echo "Java sürümü: $java_version"

# 5️⃣ Buildozer init (eğer gerekirse)
if [ ! -f "buildozer.spec" ]; then
    print_warning "buildozer.spec bulunamadı, oluşturuluyor..."
    buildozer init
fi

# 6️⃣ İlk build (SDK indirme için)
print_step "Android SDK indiriliyor..."
echo "Bu adım uzun sürebilir (5-10 dakika)..."

# Android SDK lisanslarını kabul et
mkdir -p ~/.android
echo "8933bad161af4178b1185d1a37fbf41ea5269c55" > ~/.android/repositories.cfg

# İlk build denemesi (SDK kurulumu için)
buildozer android debug || print_warning "İlk build denemesi tamamlandı (normal)"

# 7️⃣ Ana APK build
print_step "APK oluşturuluyor..."
echo "Ana build başlıyor..."

buildozer android debug

# 8️⃣ Sonuç kontrolü
if [ -d "bin" ] && [ -n "$(ls -A bin/*.apk 2>/dev/null)" ]; then
    print_success "APK başarıyla oluşturuldu!"
    echo ""
    echo "📁 APK Dosyası:"
    ls -la bin/*.apk
    echo ""
    echo "📊 APK Boyutu:"
    du -h bin/*.apk
    echo ""
    echo "🎉 PhotoVideoEditor APK hazır!"
    echo "📱 Telefona yüklemek için bin/ klasöründeki APK dosyasını kullan"
else
    print_error "APK oluşturulamadı!"
    echo ""
    echo "🔧 Troubleshooting:"
    echo "1. İnternet bağlantınızı kontrol edin"
    echo "2. Disk alanınızı kontrol edin (min 2GB gerekli)"
    echo "3. Build log'ları inceleyin"
    echo ""
    echo "📝 Build tekrar denemek için:"
    echo "buildozer appclean && buildozer android debug"
fi

echo ""
echo "🏁 Build işlemi tamamlandı!" 